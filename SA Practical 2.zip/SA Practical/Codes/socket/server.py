import socket

# Define server host and port
HOST = 'localhost'
PORT = 12345

# Create a server socket (IPv4, TCP)
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Bind the socket to the address and port
server_socket.bind((HOST, PORT))

# Listen for incoming connections
server_socket.listen(1)
print(f"Server is listening on {HOST}:{PORT}")

# Accept a client connection
client_socket, client_address = server_socket.accept()
print(f"Connected to client: {client_address}")

# Chat loop
while True:
    # Receive a message from the client
    message = client_socket.recv(1024).decode()
    if not message or message.lower() == 'exit':
        print("Client disconnected.")
        break

    print(f"Client: {message}")

    # Send a message to the client
    response = input("Server: ")
    client_socket.send(response.encode())

    if response.lower() == 'exit':
        print("Server exiting.")
        break

# Close the connections
client_socket.close()
server_socket.close()
