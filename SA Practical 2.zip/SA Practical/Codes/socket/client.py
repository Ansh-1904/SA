import socket

# Define server host and port
HOST = 'localhost'
PORT = 12345

# Create a client socket (IPv4, TCP)
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Connect to the server
client_socket.connect((HOST, PORT))
print(f"Connected to server at {HOST}:{PORT}")

# Chat loop
while True:
    # Send a message to the server
    message = input("Client: ")
    client_socket.send(message.encode())

    if message.lower() == 'exit':
        print("Client exiting.")
        break

    # Receive a response from the server
    response = client_socket.recv(1024).decode()
    if not response or response.lower() == 'exit':
        print("Server disconnected.")
        break

    print(f"Server: {response}")

# Close the connection
client_socket.close()
