from flask import Flask, jsonify, request

app = Flask(__name__)

# Mock Service Registry (publishing and finding services)
service_registry = {
    'greet': {
        'description': 'A simple greeting service',
        'url': '/api/greet',
        'method': 'GET'
    },
    'sum': {
        'description': 'A service to sum two numbers',
        'url': '/api/sum',
        'method': 'GET'
    }
}

# Publish - Service Provider registers itself in the service registry
@app.route('/api/publish', methods=['POST'])
def publish_service():
    service_name = request.json.get('name')
    service_description = request.json.get('description')
    service_url = request.json.get('url')
    service_method = request.json.get('method')
    if service_name and service_description and service_url and service_method:
        service_registry[service_name] = {
            'description': service_description,
            'url': service_url,
            'method': service_method
        }
        return jsonify({'message': 'Service published successfully'}), 201
    else:
        return jsonify({'error': 'Invalid data provided'}), 400

# Find - Service Requestor retrieves service descriptions from the registry
@app.route('/api/find/<service_name>', methods=['GET'])
def find_service(service_name):
    service = service_registry.get(service_name)
    if service:
        return jsonify({'service': service}), 200
    else:
        return jsonify({'error': 'Service not found'}), 404

# Bind - Invoking the Service
# Example of a "Greet" service
@app.route('/api/greet', methods=['GET'])
def greet():
    return jsonify({'message': 'Hello, welcome to the web service!'}), 200

# Updated Sum Service with GET method
@app.route('/api/sum', methods=['GET'])
def sum_numbers_get():
    try:
        num1 = float(request.args.get('num1', 0))
        num2 = float(request.args.get('num2', 0))
        result = num1 + num2
        return jsonify({'result': result}), 200
    except ValueError:
        return jsonify({'error': 'Invalid input, please provide numbers.'}), 400

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=9000)
# http://localhost:9000/api/sum?num1=10&num2=20