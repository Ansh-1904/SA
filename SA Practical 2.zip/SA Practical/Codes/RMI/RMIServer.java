package RMI;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

// RMI Server class
public class RMIServer {
    public static void main(String[] args) {
        try {
            // Create and export the remote object
            CalculatorImpl calculator = new CalculatorImpl();
            
            // Create RMI registry on port 1099
            Registry registry = LocateRegistry.createRegistry(1099);
            
            // Bind the remote object in the registry
            registry.rebind("CalculatorService", calculator);
            
            System.out.println("RMI Server is running...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
