package RMI;

// public class rmiInterface {
    
// }
import java.rmi.Remote;
import java.rmi.RemoteException;

// Define a remote interface
public interface Calculator extends Remote {
    // Declare a remote method
    int add(int a, int b) throws RemoteException;
}

