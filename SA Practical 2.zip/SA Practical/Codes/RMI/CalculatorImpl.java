package RMI;

// public class Server {
    
// }
import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;

// Implement the remote interface
public class CalculatorImpl extends UnicastRemoteObject implements Calculator {
    // Constructor
    protected CalculatorImpl() throws RemoteException {
        super();
    }

    // Implement the add method
    @Override
    public int add(int a, int b) throws RemoteException {
        return a + b;
    }
}
