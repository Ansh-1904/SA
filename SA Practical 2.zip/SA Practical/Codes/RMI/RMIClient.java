package RMI;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

// RMI Client class
public class RMIClient {
    public static void main(String[] args) {
        try {
            // Locate the RMI registry
            Registry registry = LocateRegistry.getRegistry("localhost", 1099);
            
            // Look up the remote object in the registry
            Calculator calculator = (Calculator) registry.lookup("CalculatorService");
            
            // Invoke the remote method
            int result = calculator.add(5, 10);
            System.out.println("Result of addition: " + result);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
