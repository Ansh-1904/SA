from flask import Flask, request, jsonify

# Create a Flask app
app = Flask(__name__)

# Define the URL pattern for the "Hello" route, similar to a servlet mapping
@app.route('/hello', methods=['GET'])
def hello():
    # Handle GET request and return a response
    return "<h1>Hello, Welcome to Python Flask Web Service!</h1>"

# Define another endpoint that mimics a servlet's response to a POST request
@app.route('/sum', methods=['POST'])
def calculate_sum():
    try:
        # Retrieve JSON data from the request
        data = request.get_json()
        num1 = data.get('num1')
        num2 = data.get('num2')
        if num1 is not None and num2 is not None:
            # Calculate the sum of two numbers
            result = num1 + num2
            return jsonify({'result': result}), 200
        else:
            return jsonify({'error': 'Invalid input, please provide two numbers.'}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Run the Flask app
if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=9000)
# http://localhost:9000/hello