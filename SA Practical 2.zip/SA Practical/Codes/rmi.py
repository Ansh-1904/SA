import Pyro5.api

# Define the remote class
@Pyro5.api.expose
class Marketplace:
    def __init__(self):
        self.laptop_stock = 10

    def list_products(self):
        return f"Available Products: Laptop ({self.laptop_stock})"

    def purchase(self, product):
        if product.lower() == "laptop" and self.laptop_stock > 0:
            self.laptop_stock -= 1
            return f"Purchased Laptop. Remaining stock: {self.laptop_stock}"
        return f"{product} is out of stock."

# Main function to create server and client
def main():
    daemon = Pyro5.server.Daemon()  # Create a Pyro daemon
    uri = daemon.register(Marketplace)  # Register the remote object
    print(f"Marketplace Server is running. URI: {uri}")

    # Create a client to call the server
    client = Pyro5.client.Proxy(uri)
    print(client.list_products())
    print(client.purchase("laptop"))
    print(client.purchase("laptop"))

    # Keep the server running
    daemon.requestLoop()

if __name__ == "__main__":
    main()
# pip install Pyro5
