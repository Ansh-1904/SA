// Import required packages
import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;

// Define the remote interface
interface Marketplace extends Remote {
    String listProducts() throws RemoteException;
    String purchase(String product) throws RemoteException;
}

// Implement the remote interface
class MarketplaceImpl extends UnicastRemoteObject implements Marketplace {
    private static final long serialVersionUID = 1L;
    private int laptopStock = 10;

    public MarketplaceImpl() throws RemoteException {
        super();
    }

    @Override
    public String listProducts() throws RemoteException {
        return "Available Products: Laptop (" + laptopStock + ")";
    }

    @Override
    public String purchase(String product) throws RemoteException {
        if ("Laptop".equalsIgnoreCase(product) && laptopStock > 0) {
            laptopStock--;
            return "Purchased Laptop. Remaining stock: " + laptopStock;
        }
        return product + " is out of stock.";
    }
}

// Main class to create server and client
public class rmi {
    public static void main(String[] args) {
        try {
            // Create and register the server
            MarketplaceImpl server = new MarketplaceImpl();
            LocateRegistry.createRegistry(1099);
            Naming.rebind("rmi://localhost:1099/Marketplace", server);
            System.out.println("Marketplace Server is running...");

            // Create the client
            Marketplace client = (Marketplace) Naming.lookup("rmi://localhost:1099/Marketplace");
            System.out.println(client.listProducts());
            System.out.println(client.purchase("Laptop"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
